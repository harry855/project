package com.example.user.drinkcount;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText teaname = (EditText)  findViewById(R.id.tea_name);
        final EditText teaspeace = (EditText) findViewById(R.id.tea_speace);
        final EditText teaspend = (EditText ) findViewById(R.id.tea_spend);
        final EditText teacount =(EditText)findViewById(R.id.tea_count);
        final Button cal_button   =(Button)findViewById(R.id.button);
        final TextView teaend =(TextView)findViewById(R.id.tea_end);
        cal_button.setOnClickListener(new View.OnClickListener(){
        public void onClick(View view){
        Double revenut =cal_revenue(Double.parseDouble(teaspeace.getText().toString()),Double.parseDouble(teaspend.getText().toString()),Integer.parseInt(teacount.getText().toString()));
        teaend.setText(teaname.getText().toString()+"賣出後得到"+revenut+"");
        }});



    }
    public Double cal_revenue(Double price,Double cost ,int stock){
        return (price-cost)*stock;
    }
}

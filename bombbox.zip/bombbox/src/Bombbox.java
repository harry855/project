
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Arrays;
import java.util.Vector;

class Game extends JFrame implements MouseListener {

    private int width = 1500, height = 1500, mapRow = 9, mapCol = 9; //width:視窗寬、height:視窗長、mapRow:地圖row、mapCol:地圖col。
    private JButton button[][] = new JButton[width][height]; //按鈕。
    private int bombCount = 10; //固定10個炸彈。

    public int map[][] ; //地圖。
    private boolean buttonIsPress[][] ; //判斷按鈕是否按壓。
    private int mapAroundBomb[][]; //周圍有多少炸彈。
    private int direct[][] = {{0, 0}, {0, 1}, {0, -1}, {1, 0}, {-1, 0}, {1, 1}, {-1, -1}, {-1, 1}, {1, -1}}; //8方位。
    private JComboBox<String> jcb;
    private int timeCount = 0; //時間計數。
    private int timeContinue = 1; //時間繼續計數or停止。1:繼續、0:停止。
    private JPanel centerButtonPanel = new JPanel();

    Game() {
        /*視窗。*/
        setSize(width, height); //設定大小。
        
        setDefaultCloseOperation(EXIT_ON_CLOSE); //設定關閉按鈕的動作。
        setTitle("Minesweeper"); //設定標題。
        setLocationRelativeTo(this); //顯示為置中。

        /*TopBar。*/
        JPanel topPanel = new JPanel();

        ImageIcon icon = new ImageIcon("icon.png");
        JButton restart = new JButton(icon); //重新開始按鈕。
        restart.setActionCommand("r");//設定指令。
        restart.addMouseListener(this); //加入監聽。
        topPanel.add(restart);

        JLabel time = new JLabel("已經過時間：0"); //顯示目前已經過時間(秒)。
        TimerTask timertask = new TimerTask() {
            public void run() {
                if (timeContinue == 1) {
                    time.setText("已經過時間： " + (timeCount++));
                }
            }
        };
        new Timer().scheduleAtFixedRate(timertask, 0, 1000);
        topPanel.add(time);
        add(topPanel, BorderLayout.NORTH);

        String[] items = {"簡易版", "一般版", "困難版"};
        jcb = new JComboBox<>(items);
        jcb.setSelectedIndex(0);
        jcb.addItemListener((ItemEvent e) -> {
            String mode = (String) e.getItem();
            switch (mode) {
                case "簡易版":
                    mapRow = 9;
                    mapCol = 9;
                    bombCount = 10;
                    makebutton(mapRow, mapCol);
                    break;
                case "一般版":
                    mapRow = 20;
                    mapCol = 20;
                    bombCount = 50;
                    makebutton(mapRow, mapCol);
                    
                    break;
                case "困難版":
                    mapRow = 20;
                    mapCol = 30;
                    bombCount = 100;
                    makebutton(mapRow, mapCol);
                    break;
            }
        });
        mapRow = 9;
        mapCol = 9;
        makebutton(mapRow, mapCol);
        topPanel.add(jcb);
        add(topPanel, BorderLayout.NORTH);
        //jcb.addMouseListener(this);
        /*地圖按鈕。*/
        //    makebutton(mapRow, mapCol);


        /*設定地圖、找出座標周圍有多少炸彈*/
         setVisible(true);
    }

    private void makebutton(int mapRow, int mapCol) {
        centerButtonPanel.removeAll();
        centerButtonPanel.setLayout(new GridLayout(mapRow, mapCol));
        for (int i = 0; i < mapRow; i++) {
            for (int j = 0; j < mapCol; j++) {
                button[i][j] = new JButton();
                button[i][j].setBackground(Color.WHITE); //設定按鈕背景顏色。
                button[i][j].setActionCommand(i + " " + j); //設定按鈕指令。
                button[i][j].addMouseListener(this); //按鈕加入監聽。
                centerButtonPanel.add(button[i][j]);
            }
        }
        add(centerButtonPanel, BorderLayout.CENTER);
        map = new int[mapRow][mapCol];
       mapAroundBomb= new int[mapRow][mapCol];
       buttonIsPress=new boolean[mapRow][mapCol];
        setMap();
        aroundBomb();
    }

    /**
     * ********************
     * 設定地圖 :有炸彈:1、無炸彈:0* ********************
     */
    private void setMap() {
        int count = 0;
        while (count != bombCount) {
            int x = (int) (Math.random() *mapRow), y = (int) (Math.random() *mapCol); //亂數設定炸彈座標。
            if (map[x][y] == 0) {
                map[x][y] = 1;
                count++;
            }
        }
        
    }

    /**
     * ****************
     * 判斷座標周圍共有多少炸彈* ****************
     */
    private void aroundBomb() {
        for (int i = 0; i < mapRow; i++) {
            for (int j = 0; j < mapCol; j++) {
                if (map[i][j] == 1) {
                    mapAroundBomb[i][j] = -1; //炸彈本身設定為-1。
                } else {
                    for (int k = 0; k < direct.length; k++) {
                        int row = i + direct[k][0], col = j + direct[k][1];
                        if ((row >= 0 && row < mapRow && col >= 0 && col < mapCol) && map[row][col] == 1) {
                            mapAroundBomb[i][j]++;
                        }
                    }
                }
            }
        }
    }

    /**
     * *****
     * 重新開始* *****
     */
    private void restart() {
        timeCount = 1;
        timeContinue = 1;
        for (int i = 0; i < mapRow; i++) {
            Arrays.fill(map[i], 0); //initial map array
        }
        for (int i = 0; i < mapRow; i++) {
            Arrays.fill(buttonIsPress[i], false); //initial buttonIsPress
        }
        for (int i = 0; i < mapRow; i++) {
            Arrays.fill(mapAroundBomb[i], 0); //initial mapAroundBomb
        }
        for (int i = 0; i < mapRow; i++) {
            for (int j = 0; j < mapCol; j++) {
                button[i][j].setBackground(Color.WHITE);
                button[i][j].setIcon(null);
                button[i][j].setText("");
            }
        }
        setMap();
        aroundBomb();

    }

    /**
     * ****************************************************
     * 紀錄滑鼠事件：BUTTON1(滑鼠左鍵)、BUTTON2(滾輪)、BUTTON3(滑鼠右鍵)*
     * ****************************************************
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        String command[] = ((JButton) e.getSource()).getActionCommand().split(" ");
        if (command[0].equals("r")) {
            /*重新開始*/

            restart();
        } else {
            int row = Integer.parseInt(command[0]), col = Integer.parseInt(command[1]);
            if (e.getButton() == MouseEvent.BUTTON1) {
                if (map[row][col] == 1 && !buttonIsPress[row][col]) {
                    /*地雷，且按鈕沒按過。*/

                    button[row][col].setBackground(Color.RED); //設定按鈕背景為紅色。
                    for (int i = 0; i < mapRow; i++) {
                        for (int j = 0; j < mapCol; j++) {
                            if (map[i][j] == 1) {
                                ImageIcon icon=new ImageIcon("icon3.png");
                                button[i][j].setIcon(icon); //印出所有炸彈。
                            }
                        }
                    }
                    timeContinue = 0; //時間停止計時。
                    JOptionPane.showMessageDialog(null, "你踩到地雷了"); //顯示失敗訊息。
                    restart(); //重新開始。
                } else if (mapAroundBomb[row][col] == 0 && !buttonIsPress[row][col]) {
                    /*當按到周圍沒炸彈的按鈕則擴散，且按鈕沒按過。*/

                    Vector<postion> vector = new Vector<postion>(); //紀錄需要擴散的點。
                    vector.add(new postion(row, col));
                    //判斷點是否符合擴散的需求，直到vector的資料都處理完。
                    for (int i = 0; i < vector.size(); i++) {
                        for (int j = 0; j < direct.length; j++) {
                            int tempRow = direct[j][0] + vector.get(i).getRow(), tempCol = direct[j][1] + vector.get(i).getCol();
                            if ((tempRow >= 0 && tempRow < mapRow) && (tempCol >= 0 && tempCol < mapCol) && mapAroundBomb[tempRow][tempCol] == 0) {
                                boolean flag = false;
                                //檢查是否已經儲存此筆資料。
                                for (int k = 0; k < vector.size(); k++) {
                                    if (tempRow == vector.get(k).getRow() && tempCol == vector.get(k).getCol()) {
                                        flag = true;
                                        break;
                                    }
                                }
                                if (!flag) {
                                    vector.add(new postion(tempRow, tempCol)); //此擴散點不存在則儲存起來。
                                }
                            }
                        }
                    }
                    //開始擴散。
                    for (int i = 0; i < vector.size(); i++) {
                        for (int j = 0; j < direct.length; j++) {
                            int tempRow = direct[j][0] + vector.get(i).getRow(), tempCol = direct[j][1] + vector.get(i).getCol();
                            if ((tempRow >= 0 && tempRow < mapRow) && (tempCol >= 0 && tempCol < mapCol)) {
                                //非0數字才印出來。
                                if (mapAroundBomb[tempRow][tempCol] != 0) {
                                    button[tempRow][tempCol].setText(Integer.toString(mapAroundBomb[tempRow][tempCol]));
                                }
                                button[tempRow][tempCol].setBackground(Color.GRAY); //設定按鈕背景顏色。
                                buttonIsPress[tempRow][tempCol] = true; //設定按鈕為按過。
                            }
                        }
                    }
                } else if (!buttonIsPress[row][col]) {
                    /*不是炸彈、也不須擴散的點。*/

                    button[row][col].setText(Integer.toString(mapAroundBomb[row][col])); //印出數字。
                    button[row][col].setBackground(Color.GRAY); //設定按鈕背景顏色。
                    buttonIsPress[row][col] = true; //設定按鈕為按過。
                }
            } else if (buttonIsPress[row][col] && e.getButton() == MouseEvent.BUTTON3) {
                /*取消標記的炸彈按紐。*/

                buttonIsPress[row][col] = false; //取消按壓。
                button[row][col].setIcon(null); //移除。
                bombCount++; //炸彈數。

            } else if (e.getButton() == MouseEvent.BUTTON3 && !buttonIsPress[row][col]) {
                /*標記炸彈。並判斷是否結束遊戲。*/
                ImageIcon icon=new ImageIcon("icon2.png");
                ((JButton) e.getSource()).setIcon(icon); //設定按鈕背景顏色。
                buttonIsPress[row][col] = true; //設定按鈕為按過。
                bombCount--; //炸彈數。

                //判斷是否結束遊戲。
                if (bombCount == 0) {
                    boolean endGame = true;
                    //判斷有地雷的按鈕是否已經標記。
                    for (int i = 0; i < mapRow; i++) {
                        for (int j = 0; j < mapCol; j++) {
                            if (map[i][j] == 1) {
                                if (buttonIsPress[i][j] != true) {
                                    endGame = false;
                                }
                            }
                        }
                    }
                    if (endGame) {
                        timeContinue = 0; //時間停止計時。
                        JOptionPane.showMessageDialog(null, "恭喜破關"); //顯示破關訊息。
                        restart(); //重新開始遊戲。
                    }
                }
            }

        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub	
    }

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // TODO Auto-generated method stub
    }

}

abstract class table extends JFrame implements ActionListener {

}

class postion {

    private int row, col;

    postion(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }
}

class minesweeper {

    public static void main(String args[]) {
        Game g = new Game();
    }
}

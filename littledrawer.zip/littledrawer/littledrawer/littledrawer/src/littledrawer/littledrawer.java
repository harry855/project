/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package littledrawer;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import static java.awt.SystemColor.window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;

/**
 *
 * @author ttu
 */
public class littledrawer extends JFrame
        implements MouseListener, ActionListener, ComponentListener {

    private JTextArea txt;
    private JPanel panel, panelset;
    private JToolBar toolbar;
    private boolean isDragging;
    private int x, y, prevX, prevY, color, size;
    private JButton blue, black, red, gray, green, square, circle, line, pen;
    private Container c = getContentPane();
    private int w,z;
    private  BufferedImage abc=new BufferedImage(600,500,BufferedImage.TYPE_INT_ARGB);
    public littledrawer() {
        super("基本滑鼠事件範例");
        c.setLayout(new BorderLayout());
        c.setBackground(Color.white);
        panel = new JPanel();
        panel.setBorder(BorderFactory.createEtchedBorder());
        panel.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent evt) {
                if (isDragging == true) {
                    return;
                }
                isDragging = true;
                x = evt.getX();
                y = evt.getY();
                prevX = x;
                prevY = y;
            }

            public void mouseReleased(MouseEvent evt) {
                isDragging = false;
                if (size == 0) {
                    int tempX = evt.getX(), tempY = evt.getY();
                    w=tempX;z=tempY;
                    paintsquare(tempX, tempY);
                    
                
                }
                if (size == 2) {
                    int tempX = evt.getX(), tempY = evt.getY();
                    w=tempX;z=tempY;
                    paint(tempX, tempY);
                   
                }
                if (size == 3) {
                    int tempX = evt.getX(), tempY = evt.getY();
                    w=tempX;z=tempY;
                    paintcircle(tempX, tempY);
                    
                }
              //  repaint();
            }
        });

        panel.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent evt) {

                if (isDragging == false) {
                    return;
                }
                int tempX = evt.getX(), tempY = evt.getY();
                w=tempX;z=tempY;
                if (size == 1) {
                    paint(tempX, tempY);
                }
                
            }
        });

        toolbar = new JToolBar();
        ImageIcon icon = new ImageIcon("square.png");
        square = new JButton(icon);
        square.setMaximumSize(new Dimension(30, 30));
        toolbar.add(square);
        square.addActionListener(this);
        ImageIcon icon2 = new ImageIcon("pen.png");
        pen = new JButton(icon2);
        pen.setMaximumSize(new Dimension(30, 30));
        pen.addActionListener(this);
        toolbar.add(pen);
        ImageIcon icon3 = new ImageIcon("line.png");
        line = new JButton(icon3);
        line.setMaximumSize(new Dimension(30, 30));
        line.addActionListener(this);
        toolbar.add(line);
        ImageIcon icon4 = new ImageIcon("circle.png");
        circle = new JButton(icon4);
        circle.setMaximumSize(new Dimension(30, 30));
        circle.addActionListener(this);
        toolbar.add(circle);
        blue = new JButton();
        blue.setBackground(Color.BLUE);
        blue.addActionListener(this);
        blue.setMaximumSize(new Dimension(30, 30));
        toolbar.add(blue);
        red = new JButton();
        red.setBackground(Color.RED);
        red.setMaximumSize(new Dimension(30, 30));
        red.addActionListener(this);
        toolbar.add(red);
        black = new JButton();
        black.setBackground(Color.BLACK);
        black.setMaximumSize(new Dimension(30, 30));
        black.addActionListener(this);
        toolbar.add(black);
        gray = new JButton();
        gray.setBackground(Color.GRAY);
        gray.setMaximumSize(new Dimension(30, 30));
        gray.addActionListener(this);
        toolbar.add(gray);
        green = new JButton();
        green.setBackground(Color.green);
        green.setMaximumSize(new Dimension(30, 30));
        green.addActionListener(this);
        toolbar.add(green);
        panelset = new JPanel();
        panelset.add(toolbar);
        c.add(panelset, BorderLayout.NORTH);
        c.add(panel, BorderLayout.CENTER);
        panel.addComponentListener(this);

    }

    public void mousePressed(MouseEvent evt) {
    }

    public void mouseEntered(MouseEvent evt) {
    }

    public void mouseExited(MouseEvent evt) {
    }

    public void mouseClicked(MouseEvent evt) {

    }

    public void mouseReleased(MouseEvent evt) {
    }

    public void paint(int tempX, int tempY) {
        Graphics g = panel.getGraphics();
        Graphics g2=abc.getGraphics();
        
        if (color == 1) {
            g.setColor(Color.red);
             g2.setColor(Color.red);
        } else if (color == 0) {
            g.setColor(Color.BLACK);
            g2.setColor(Color.BLACK);
        } else if (color == 2) {
            g.setColor(Color.blue);
            g2.setColor(Color.blue);
        } else if (color == 3) {
            g.setColor(Color.GRAY);
            g2.setColor(Color.GRAY);
        } else if (color == 4) {
            g.setColor(Color.green);
            g2.setColor(Color.green);
        }
        g.drawLine(prevX, prevY, tempX, tempY);
         g2.drawLine(prevX, prevY, tempX, tempY);
        prevX = tempX;
        prevY = tempY;
    }

    public void paintsquare(int tempX, int tempY) {
        Graphics g = panel.getGraphics();
        Graphics g2=abc.getGraphics();
        
        if (color == 1) {
            g.setColor(Color.red);
             g2.setColor(Color.red);
        } else if (color == 0) {
            g.setColor(Color.BLACK);
            g2.setColor(Color.BLACK);
        } else if (color == 2) {
            g.setColor(Color.blue);
            g2.setColor(Color.blue);
        } else if (color == 3) {
            g.setColor(Color.GRAY);
            g2.setColor(Color.GRAY);
        } else if (color == 4) {
            g.setColor(Color.green);
            g2.setColor(Color.green);
        }
        if (tempX < x) {
            int w;
            w = x;
            x = tempX;
            tempX = w;
        }
        if (tempY < y) {
            int w;
            w = y;
            y = tempY;
            tempY = w;
        }
        int length = tempX - x;
        int wigth = tempY - y;
        g.drawRect(x, y, length, wigth);
        g2.drawRect(x, y, length, wigth);
    }

    public void paintcircle(int tempX, int tempY) {

        Graphics g = panel.getGraphics();
       Graphics g2=abc.getGraphics();
       
        if (color == 1) {
            g.setColor(Color.red);
             g2.setColor(Color.red);
        } else if (color == 0) {
            g.setColor(Color.BLACK);
            g2.setColor(Color.BLACK);
        } else if (color == 2) {
            g.setColor(Color.blue);
            g2.setColor(Color.blue);
        } else if (color == 3) {
            g.setColor(Color.GRAY);
            g2.setColor(Color.GRAY);
        } else if (color == 4) {
            g.setColor(Color.green);
            g2.setColor(Color.green);
        }
        if (tempX < x) {
            int w;
            w = x;
            x = tempX;
            tempX = w;
        }
        if (tempY < y) {
            int w;
            w = y;
            y = tempY;
            tempY = w;
        }
        int length = tempX - x;
        int wigth = tempY - y;
        g.drawOval(x, y, length, wigth);
        g2.drawOval(x, y, length, wigth);
    }
    public void paintComponent(Graphics g){
        if (size == 0) {
                    paintsquare(w, z);
                }
                if (size == 2) {
                    
                    paint(w, z);
                }
                if (size == 3) {
                   
                    paintcircle(w, z);
                }
                if (size == 1) {
                    paint(w, z);
                }
    }
    public void actionPerformed(ActionEvent evt) {
        if (evt.getSource() == black) {
            color = 0;
        } else if (evt.getSource() == red) {
            color = 1;
        } else if (evt.getSource() == blue) {
            color = 2;
        } else if (evt.getSource() == gray) {
            color = 3;
        } else if (evt.getSource() == green) {
            color = 4;
        } else if (evt.getSource() == square) {
            size = 0;
        } else if (evt.getSource() == pen) {
            size = 1;
        } else if (evt.getSource() == line) {
            size = 2;
        } else if (evt.getSource() == circle) {
            size = 3;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        littledrawer app = new littledrawer();
        app.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        app.setSize(600, 500);
        app.setVisible(true);
    }

    @Override
    public void componentResized(ComponentEvent e) {
        try {
            panel.getGraphics().drawImage(abc, 0, 0, null);
            Dimension size = panel.getSize();       
           // g2.dispose();
            int num = size.width;
            new File("abc").mkdir();
            File file = new File("abc", num + ".png");
            ImageIO.write(abc, "png", file);

        } catch (Exception evt) {
            evt.printStackTrace();
        }
    }

    @Override
    public void componentMoved(ComponentEvent e) {

    }

    @Override
    public void componentShown(ComponentEvent e) {

    }

    @Override
    public void componentHidden(ComponentEvent e) {

    }

}
